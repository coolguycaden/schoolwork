#include "function.h"

int main(){
	printName();
}
