#include "function.h"

void printName(){
	printf("Hello World! My name is Caden");
}
